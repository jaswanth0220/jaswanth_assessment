﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Jaswanth__Assessment
{
    internal class Excerise1
    {
        static void Main()
        {
            double principal = 1000.00;
            double rate = 0.05;
            double amount = 100000;
            int years = 0;
            while (principal < amount)
            {
                principal += principal * rate;
                years++;
            }
            Console.WriteLine("It will take " + 
                years + " years to reach " + amount);
        }
    }
}
