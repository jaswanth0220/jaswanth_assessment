﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Formats.Asn1.AsnWriter;
using System.IO;
namespace Jaswanth__Assessment
{
    
    class Car {

        public string Model;
        public DateTime Year;

        public Car(string model, DateTime year)
        {
            Model = model;
            Year = year;
        }

        public void FileStoring(string path)
        {
            try
            {
                string content = "The car model is "+ Model + " And the year is  " + Year;
                File.WriteAllText(path, content);
                Console.WriteLine("File is stored in the path");
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            
            
        }
    }

    internal class Excerise3
    {
       
        static void Main()
        { 
            Console.WriteLine("Enter the Car Model Name");
            string model = Console.ReadLine();
            Console.WriteLine("Enter the Car Year");
            DateTime year= DateTime.Parse(Console.ReadLine());
    
                Car car = new Car(model, year);
            Console.WriteLine("Enter the path to store the file");
            string path = Console.ReadLine();
            car.FileStoring(path);

        }
    }

    
}
