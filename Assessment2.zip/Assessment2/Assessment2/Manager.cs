﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Assessment2
{

    
    internal interface IBooks
    {
        void CreateBook(Books book);
        
        void UpdateBook(int bookId, string bookName, double bookPrice, string bookAuthor, string bookPublisher);
        void DisplayId(int bookId);
        void DisplayByBookName(string bookName);
        void DisplayByAuthor(string bookAuthor);
      
        void DisplayAuthorAndPublisher(string bookAuthor, string bookPublisher);
        
        List<Books> GetBooks();
    }

    class BooksRepository : IBooks
    { 
      
        public List<Books> books = new List<Books>();

        public void CreateBook(Books book)
        {
            books.Add(book);
        }

        public void UpdateBook(int bookId, string bookName, double bookPrice, string bookAuthor, string bookPublisher)
        {
            foreach (Books book in books)
            {
                try
                {
                    if (book.BookId == bookId)
                    {
                        book.BookName = bookName;
                        book.BookPrice = bookPrice;
                        book.BookAuthor = bookAuthor;
                        book.BookPublisher = bookPublisher;
                    }
                    else
                    {
                        Console.WriteLine("Sorry the the id is wrong");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Invalid type ");
                }
               
            }
        }

        public void DisplayId(int bookId)
        {

           foreach (Books book in books)
            {
                try
                {
                    if (book.BookId == bookId)
                    {
                        Console.WriteLine("Book Id: " + book.BookId);
                        Console.WriteLine("Book Name: " + book.BookName);
                        Console.WriteLine("Book Price: " + book.BookPrice);
                        Console.WriteLine("Book Author: " + book.BookAuthor);
                        Console.WriteLine("Book Publisher: " + book.BookPublisher);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Invalid type");
                }
               
            }
        }

        public void DisplayByBookName(string bookName)
        {

            foreach(Books book in books)
            {
                try
                {
                    if (book.BookName == bookName)
                    {
                        Console.WriteLine("Book Id: " + book.BookId);
                        Console.WriteLine("Book Name: " + book.BookName);
                        Console.WriteLine("Book Price: " + book.BookPrice);
                        Console.WriteLine("Book Author: " + book.BookAuthor);
                        Console.WriteLine("Book Publisher: " + book.BookPublisher);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Enter correct details");
                }
                
        }  

    }

        public void DisplayByAuthor(string bookAuthor)
        {

            foreach(Books book in books)
            {
                try
                {
                    if (book.BookAuthor == bookAuthor)
                    {

                        Console.WriteLine("Book Id: " + book.BookId);
                        Console.WriteLine("Book Name: " + book.BookName);
                        Console.WriteLine("Book Price: " + book.BookPrice);
                        Console.WriteLine("Book Author: " + book.BookAuthor);
                        Console.WriteLine("Book Publisher: " + book.BookPublisher);
                    }
                }catch(Exception e)
                {
                    Console.WriteLine("Enter correct details");
                }
               
            }
        }

        public void DisplayAuthorAndPublisher(string bookAuthor, string bookPublisher)
        {
            foreach(Books book in books)
            {
                try
                {
                    if (book.BookAuthor == bookAuthor && book.BookPublisher == bookPublisher)
                    {
                        Console.WriteLine("Book Id: " + book.BookId);
                        Console.WriteLine("Book Name: " + book.BookName);
                        Console.WriteLine("Book Price: " + book.BookPrice);
                        Console.WriteLine("Book Author: " + book.BookAuthor);
                        Console.WriteLine("Book Publisher: " + book.BookPublisher);
                    }
                }
                catch(Exception e) { Console.WriteLine("the details you have entered are wrong"); }
               
            }
        }

        public List<Books> GetBooks()
        {
            return books;
        }
        
            
    
    }


    internal class Manager
    {
        static void Main()
        {
           
            
            BooksRepository booksRepository = new BooksRepository();
            
            while(true)
            {
                Console.WriteLine("Select the option" +
                "\n 1. Add Book\n 2. Update Book\n 3. Display Book by Id \n 4. Display Book by Name \n5. Display Book by Author \n6. Display Book by Author and Publisher \n 7.Display all books \n 8.Exit");

                int option = int.Parse(Console.ReadLine());
                switch (option)
                {
                    case 1:
                        {
                            Console.WriteLine("enter the Book Id");
                            int Id = int.Parse(Console.ReadLine());
                            Console.WriteLine("enter the Name of the book");
                            string Bokname = Console.ReadLine();
                            Console.WriteLine("Enter the Price of the book");
                            double price = double.Parse(Console.ReadLine());
                            Console.WriteLine("Enter the Author name");
                            string authorName = Console.ReadLine();
                            Console.WriteLine("Enter the publisher name");
                            string Publisher = Console.ReadLine();
                            Books book = new Books(Id, Bokname, price, authorName, Publisher);
                            booksRepository.CreateBook(book);
                            break;
                        }
                    case 2:
                        {
                            Console.WriteLine("Enter the Book Id");
                            int Id = int.Parse(Console.ReadLine());
                            Console.WriteLine("Enter the Book Name");
                            string Bokname = Console.ReadLine();
                            Console.WriteLine("Enter the Book Price");
                            double price = int.Parse(Console.ReadLine());
                            Console.WriteLine("Enter the Book Author");
                            string authorName = Console.ReadLine();
                            Console.WriteLine("Enter the Book Publisher");
                            string Publisher = Console.ReadLine();
                            booksRepository.UpdateBook(Id, Bokname, price, authorName, Publisher);
                            break;
                        }
                    case 3:
                        {
                            Console.WriteLine("enter the id to display the details");
                            int Id = int.Parse(Console.ReadLine());
                            booksRepository.DisplayId(Id);
                            break;
                        }
                    case 4:
                        {
                            Console.WriteLine("Enter the book name you want to find");
                            string BookName = Console.ReadLine();
                            booksRepository.DisplayByBookName(BookName);
                            break;
                        }
                    case 5:
                        {
                            Console.WriteLine("enter the name of the Author");
                            string AuthorName = Console.ReadLine();
                            booksRepository.DisplayByAuthor(AuthorName);
                            break;
                        }
                    case 6:
                        {
                            Console.WriteLine("Enter the book name you want to find");
                            string BookName = Console.ReadLine();
                            Console.WriteLine("enter the name of the Author");
                            string AuthorName = Console.ReadLine();
                            booksRepository.DisplayAuthorAndPublisher(BookName, AuthorName);
                        }
                        break;

                    case 7:
                        {
                            
                            var allBooks = booksRepository.GetBooks();
                            if (allBooks!=null)
                            {
                                foreach (var book in allBooks)
                                {
                                    Console.WriteLine($"The book name is {book.BookName} and price is {book.BookPrice} and author name is {book.BookAuthor} and published by{book.BookPublisher}");
                                }
                            }
                            else
                            {
                                Console.WriteLine("No books available.");
                            }
                            break;

                        }
                    default:
                        Console.WriteLine("Invalid option");
                        break;
                    case 8:
                        {

                            Environment.Exit(0);
                            break;

                        }
                }
            }
        }
    }
}
