﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assessment2
{
    internal class Books
    {
        public int BookId { get; set; }
        public string BookName { get; set; }
        public double BookPrice { get; set; }
        public string BookAuthor { get; set; }
        public string BookPublisher { get; set; }

        
        public Books(int bookId, string bookName, double bookPrice, string bookAuthor, string bookPublisher)
        {
            BookId = bookId;
            BookName = bookName;
            BookPrice = bookPrice;
            BookAuthor = bookAuthor;
            BookPublisher = bookPublisher;
        }
        
        static void Main()
        {
            //Books books = new Books(1, "C# Programming", 100, "John Doe", "ABC Publications");
        }

      
    }

    
}
